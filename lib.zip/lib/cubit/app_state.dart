// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:convert';

import 'package:flutter/cupertino.dart';

import 'package:detailmanagement/main.dart';

@immutable
class UserState {
  List<Model> users;

  UserState(this.users);

  @override
  List<Object?> get props => [];

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'users': users.map((x) => x.toMap()).toList(),
    };
  }

  factory UserState.fromMap(Map<String, dynamic> map) {
    return UserState(
      List<Model>.from(
        (map['users'] as List<int>).map<Model>(
          (x) => Model.fromMap(x as Map<String, dynamic>),
        ),
      ),
    );
  }

  String toJson() => json.encode(toMap());

  factory UserState.fromJson(String source) =>
      UserState.fromMap(json.decode(source) as Map<String, dynamic>);
}
